//
//  VideoViewController.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 Gurpreet. All rights reserved.
//

import UIKit
import AVKit

class VideoViewController: UIViewController {

    var video = AVPlayer()
    var videoPlayer = AVPlayerViewController()
    
    @IBOutlet weak var lblText: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       

        // Do any additional setup after loading the view.
    }
    
    @IBAction func playVideo(_ sender: UIButton) {
        
        if let path = Bundle.main.path(forResource: "video", ofType: "mp4"){
            
            self.video = AVPlayer(url: URL(fileURLWithPath: path))
            self.videoPlayer = AVPlayerViewController()
            self.videoPlayer.player = video
            
            self.present(self.videoPlayer, animated: true, completion: {
                self.video.play()
            })
        }        
        
}
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
