//
//  IMGCollectionViewCell.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 Gurpreet. All rights reserved.
//

import UIKit

class IMGCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
